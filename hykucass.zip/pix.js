/**
 * Adaptador de Pix do HykuCass.
 * PIX_PROVIDER=mock   → testes locais (padrão)
 * PIX_PROVIDER=asaas  → produção com Asaas
 *
 * Asaas: https://docs.asaas.com/reference
 * Variáveis:
 *   ASAAS_API_KEY=$aact_xxxx
 *   ASAAS_WEBHOOK_TOKEN=xxxx   (painel Asaas → Integrações → Webhook)
 *   PIX_EXPIRY_SECONDS=3600
 */
const crypto = require('crypto');
const PROVIDER = process.env.PIX_PROVIDER || 'mock';
const BASE = process.env.ASAAS_SANDBOX === '1'
  ? 'https://sandbox.asaas.com/api/v3'
  : 'https://api.asaas.com/api/v3';
const KEY = process.env.ASAAS_API_KEY || '';
const WH_TOKEN = process.env.ASAAS_WEBHOOK_TOKEN || '';
const EXPIRY = Number(process.env.PIX_EXPIRY_SECONDS || 3600);

const asaas = {
  async createCharge({ id, amount, user }) {
    // 1. garante que o cliente existe no Asaas
    const cRes = await fetch(BASE + '/customers?email=' + encodeURIComponent(user.email), {
      headers: { 'access_token': KEY }
    });
    const cData = await cRes.json();
    let customerId = cData.data?.[0]?.id;
    if (!customerId) {
      const cr = await fetch(BASE + '/customers', {
        method: 'POST', headers: { 'access_token': KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: user.email.split('@')[0], email: user.email })
      });
      customerId = (await cr.json()).id;
    }
    if (!customerId) throw new Error('Asaas: não foi possível criar o cliente');

    // 2. cria a cobrança Pix
    const due = new Date(Date.now() + EXPIRY * 1000).toISOString().slice(0, 10);
    const r = await fetch(BASE + '/payments', {
      method: 'POST', headers: { 'access_token': KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ customer: customerId, billingType: 'PIX', value: amount / 100,
        dueDate: due, description: 'Depósito HykuCass', externalReference: id })
    });
    if (!r.ok) throw new Error('Asaas createCharge: ' + await r.text());
    const pay = await r.json();

    // 3. busca o QR Code copia e cola
    const qr = await fetch(BASE + '/payments/' + pay.id + '/pixQrCode', { headers: { 'access_token': KEY } });
    const qrData = await qr.json();
    return { providerRef: pay.id, code: qrData.payload };
  },

  verifyWebhook(raw, headers) {
    // Asaas envia asaas-access-token no cabeçalho
    const token = String(headers['asaas-access-token'] || '');
    if (!WH_TOKEN || token.length !== WH_TOKEN.length ||
        !crypto.timingSafeEqual(Buffer.from(token), Buffer.from(WH_TOKEN))) return null;
    try {
      const ev = JSON.parse(raw);
      if (ev.event !== 'PAYMENT_RECEIVED' && ev.event !== 'PAYMENT_CONFIRMED') return null;
      return { providerRef: ev.payment?.id };
    } catch { return null; }
  }
};

const mock = {
  isMock: true,
  createCharge: ({ id }) => ({ providerRef: 'mock_' + id, code: 'HYKUCASS-MOCK-PIX-' + id }),
  verifyWebhook(raw, headers) {
    const SECRET = process.env.PIX_WEBHOOK_SECRET || 'troque-este-segredo';
    const sig = Buffer.from(String(headers['x-signature'] || ''), 'hex');
    const exp = crypto.createHmac('sha256', SECRET).update(raw).digest();
    if (sig.length !== exp.length || !crypto.timingSafeEqual(sig, exp)) return null;
    try { return { providerRef: JSON.parse(raw).providerRef }; } catch { return null; }
  },
  sign: raw => crypto.createHmac('sha256', process.env.PIX_WEBHOOK_SECRET || 'troque-este-segredo').update(raw).digest('hex')
};

module.exports = PROVIDER === 'asaas' ? asaas : mock;
