const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const cfg = require('./config'), engine = require('./engine'), auth = require('./auth'), wallet = require('./wallet'), pix = require('./pix');
const { db, tx, UserError } = require('./db');
const PORT = process.env.PORT || 3000, PUB = path.join(__dirname, 'public'), ADMIN = process.env.ADMIN_TOKEN || '';
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript' };
const json = (res, code, o) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
const raw = req => new Promise((ok, no) => { let d = ''; req.on('data', c => { d += c; if (d.length > 2e4) { req.destroy(); no(new Error('grande')); } }); req.on('end', () => ok(d)); });
const now = () => new Date().toISOString();
const need = (u) => { if (!u) { const e = new UserError('Faça login'); e.code = 401; throw e; } return u; };
const isAdmin = req => { const a = Buffer.from(String(req.headers['x-admin-token'] || '')), b = Buffer.from(ADMIN);
  return ADMIN.length >= 16 && a.length === b.length && crypto.timingSafeEqual(a, b); };

function confirmCharge(providerRef) { // idempotente: só credita uma vez
  return tx(() => {
    const c = db.prepare('SELECT * FROM pix_charges WHERE provider_ref=?').get(providerRef);
    if (!c || c.status !== 'pending') return false;
    db.prepare("UPDATE pix_charges SET status='paid' WHERE id=?").run(c.id);
    wallet.post(c.user_id, 'deposit', c.amount, c.id); return true;
  });
}
const cookie = t => `sid=${t}; HttpOnly; SameSite=Strict; Path=/; Max-Age=604800` + (process.env.NODE_ENV === 'production' ? '; Secure' : '');

http.createServer(async (req, res) => {
  try {
    const url = req.url.split('?')[0], post = req.method === 'POST';
    res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('X-Frame-Options', 'DENY');
    if (url.startsWith('/api/')) {
      let body = {}, rawBody = '';
      if (post) { rawBody = await raw(req);
        if (url !== '/api/pix/webhook') { if (!/application\/json/.test(req.headers['content-type'] || '')) return json(res, 415, { error: 'JSON obrigatório' }); body = JSON.parse(rawBody || '{}'); } }
      const ip = req.socket.remoteAddress;
      if (url === '/api/config') return json(res, 200, { games: cfg.games, mock: !!pix.isMock });
      if (url === '/api/register' && post) { res.setHeader('Set-Cookie', cookie(auth.register(body))); return json(res, 200, { ok: true }); }
      if (url === '/api/login' && post) { res.setHeader('Set-Cookie', cookie(auth.login(body, ip))); return json(res, 200, { ok: true }); }
      if (url === '/api/logout' && post) { auth.logout(req); return json(res, 200, { ok: true }); }
      if (url === '/api/pix/webhook' && post) { const v = pix.verifyWebhook(rawBody, req.headers); if (!v) return json(res, 401, { error: 'assinatura' }); confirmCharge(v.providerRef); return json(res, 200, { ok: true }); }
      if (url.startsWith('/api/admin/')) {
        if (!isAdmin(req)) return json(res, 403, { error: 'Acesso negado' });
        if (url === '/api/admin/withdrawals') return json(res, 200, db.prepare("SELECT * FROM withdrawals WHERE status='pending' ORDER BY id").all());
        let m = /^\/api\/admin\/withdrawals\/(\d+)\/(approve|reject)$/.exec(url);
        if (m && post) return json(res, 200, tx(() => { const w = db.prepare('SELECT * FROM withdrawals WHERE id=?').get(+m[1]);
          if (!w || w.status !== 'pending') throw new UserError('Saque não está pendente');
          db.prepare('UPDATE withdrawals SET status=? WHERE id=?').run(m[2] === 'approve' ? 'approved' : 'rejected', w.id);
          if (m[2] === 'reject') wallet.post(w.user_id, 'withdraw_refund', w.amount, 'w' + w.id); return { ok: true }; }));
        if (url === '/api/admin/kyc' && post && ['pending', 'verified', 'blocked'].includes(body.status)) {
          db.prepare('UPDATE users SET kyc=? WHERE id=?').run(body.status, +body.userId); return json(res, 200, { ok: true }); }
        return json(res, 404, { error: 'não encontrado' });
      }
      const u = need(auth.user(req));
      if (url === '/api/me') return json(res, 200, u);
      if (url === '/api/history') return json(res, 200, db.prepare('SELECT type,amount,balance_after,created FROM ledger WHERE user_id=? ORDER BY id DESC LIMIT 20').all(u.id));
      if (url === '/api/play' && post) {
        const g = cfg.games[body.game];
        if (!g) throw new UserError('Jogo inválido');
        if (u.kyc === 'blocked') throw new UserError('Conta bloqueada');
        if (!Number.isInteger(body.bet) || body.bet < g.minBet || body.bet > g.maxBet) throw new UserError('Aposta fora dos limites');
        return json(res, 200, tx(() => {
          const r = engine.play(body.game, body.choice); if (!r) throw new UserError('Escolha inválida');
          const id = crypto.randomUUID(), payout = Math.floor(body.bet * r.mult);
          wallet.post(u.id, 'bet', -body.bet, id); const balance = payout > 0 ? wallet.post(u.id, 'win', payout, id) : u.balance - body.bet;
          db.prepare('INSERT INTO rounds VALUES(?,?,?,?,?,?,?,?)').run(id, u.id, body.game, JSON.stringify(body.choice), body.bet, payout, JSON.stringify(r.detail), now());
          return { detail: r.detail, payout, balance: db.prepare('SELECT balance FROM users WHERE id=?').get(u.id).balance };
        }));
      }
      if (url === '/api/pix/deposit' && post) {
        if (!Number.isInteger(body.amount) || body.amount < 1000 || body.amount > 500000) throw new UserError('Depósito entre R$ 10,00 e R$ 5.000,00');
        const id = crypto.randomUUID(), c = pix.createCharge({ id, amount: body.amount, user: u });
        db.prepare("INSERT INTO pix_charges VALUES(?,?,?,'pending',?,?,?)").run(id, u.id, body.amount, c.providerRef, c.code, now());
        return json(res, 200, { id, code: c.code });
      }
      let m = /^\/api\/pix\/([\w-]+)$/.exec(url);
      if (m) { const c = db.prepare('SELECT id,amount,status FROM pix_charges WHERE id=? AND user_id=?').get(m[1], u.id); return c ? json(res, 200, c) : json(res, 404, { error: 'não encontrado' }); }
      if (url === '/api/dev/pix/pay' && post && pix.isMock) { const c = db.prepare('SELECT provider_ref FROM pix_charges WHERE id=? AND user_id=?').get(String(body.id), u.id);
        return c ? json(res, 200, { ok: confirmCharge(c.provider_ref) }) : json(res, 404, { error: 'não encontrado' }); }
      if (url === '/api/withdraw' && post) {
        if (u.kyc !== 'verified') throw new UserError('Verificação de identidade (KYC) pendente');
        if (!Number.isInteger(body.amount) || body.amount < 2000) throw new UserError('Saque mínimo de R$ 20,00');
        const key = String(body.pixKey || '').trim(); if (key.length < 5 || key.length > 100) throw new UserError('Chave Pix inválida');
        return json(res, 200, tx(() => { const r = db.prepare("INSERT INTO withdrawals(user_id,amount,pix_key,status,created) VALUES(?,?,?,'pending',?)").run(u.id, body.amount, key, now());
          wallet.post(u.id, 'withdraw_hold', -body.amount, 'w' + r.lastInsertRowid); return { id: Number(r.lastInsertRowid), status: 'pending' }; }));
      }
      return json(res, 404, { error: 'não encontrado' });
    }
    const file = path.join(PUB, url === '/' ? 'index.html' : url);
    if (!file.startsWith(PUB)) { res.writeHead(403); return res.end(); }
    fs.readFile(file, (e, d) => { if (e) { res.writeHead(404); return res.end('Not found'); }
      res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' }); res.end(d); });
  } catch (e) {
    if (e instanceof UserError) return json(res, e.code || 400, { error: e.message });
    console.error(e); json(res, 500, { error: 'Erro interno' });
  }
}).listen(PORT, () => console.log('HykuCass em http://localhost:' + PORT));
