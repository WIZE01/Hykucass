// Carteira: todo movimento passa por post() dentro de uma transação e deixa rastro no ledger.
const { db, UserError } = require('./db');
function post(userId, type, amount, ref) {
  const nb = db.prepare('SELECT balance FROM users WHERE id=?').get(userId).balance + amount;
  if (nb < 0) throw new UserError('Saldo insuficiente');
  db.prepare('UPDATE users SET balance=? WHERE id=?').run(nb, userId);
  db.prepare('INSERT INTO ledger(user_id,type,amount,balance_after,ref,created) VALUES(?,?,?,?,?,?)')
    .run(userId, type, amount, nb, ref || null, new Date().toISOString());
  return nb;
}
module.exports = { post };
