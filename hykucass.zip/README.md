# HykuCass — base do cassino (Node.js 22+, sem dependências)

    npm start            # http://localhost:3000
    npm run simulate     # RTP real de cada aposta

## Subir no Railway (passo a passo)

1. Crie uma conta em https://railway.app
2. Instale o GitHub e suba este projeto em um repositório privado
3. No Railway: New Project → Deploy from GitHub repo → selecione o repositório
4. Vá em Variables e adicione as variáveis abaixo
5. O Railway detecta automaticamente o Node.js e faz o deploy
6. Acesse em Settings → Domains → Generate Domain
   (você ganha hykucass.up.railway.app ou similar, com HTTPS)

## Variáveis de ambiente no Railway

| Variável             | Valor para começar              |
|----------------------|---------------------------------|
| NODE_ENV             | production                      |
| ADMIN_TOKEN          | (gere um token com 32+ chars)   |
| PIX_PROVIDER         | mock (troque por asaas depois)  |
| PIX_WEBHOOK_SECRET   | (qualquer string secreta)       |
| DB_FILE              | /data/hykucass.db               |

Atenção: o banco SQLite precisa de um volume persistente no Railway.
Em New Project → Add Volume → monte em /data

## Trocar para Asaas (quando o cadastro estiver pronto)

Adicione nas variáveis:
  PIX_PROVIDER=asaas
  ASAAS_API_KEY=$aact_xxxx
  ASAAS_WEBHOOK_TOKEN=xxxx

E aponte o webhook no painel Asaas para:
  https://seudominio.up.railway.app/api/pix/webhook

## Arquivos

- config.js   pagamentos e limites (centavos)
- engine.js   motor dos 4 jogos com RNG criptográfico
- db.js       banco SQLite
- auth.js     cadastro e login
- wallet.js   ledger de movimentos
- pix.js      adaptador Pix (mock agora, Asaas depois)
- server.js   API e site
- public/     site (celular e desktop)
- railway.toml + .nixpacks.toml  configuração do Railway

## Admin (cabeçalho x-admin-token)

- GET  /api/admin/withdrawals
- POST /api/admin/withdrawals/{id}/approve|reject
- POST /api/admin/kyc {"userId":1,"status":"verified"}
