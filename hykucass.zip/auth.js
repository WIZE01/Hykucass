const crypto = require('crypto');
const { db, UserError } = require('./db');
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const DAY = 864e5;
function adult(birth) {
  const d = new Date(birth + 'T00:00:00Z'); if (isNaN(d)) return false;
  const lim = new Date(); lim.setUTCFullYear(lim.getUTCFullYear() - 18); return d <= lim;
}
const hash = pw => { const s = crypto.randomBytes(16).toString('hex'); return s + ':' + crypto.scryptSync(pw, s, 64).toString('hex'); };
const check = (pw, h) => { const [s, k] = h.split(':'); return crypto.timingSafeEqual(Buffer.from(k, 'hex'), crypto.scryptSync(pw, s, 64)); };
const tries = new Map();
function limit(key) { const t = tries.get(key) || { n: 0, reset: Date.now() + 9e5 };
  if (Date.now() > t.reset) { t.n = 0; t.reset = Date.now() + 9e5; }
  if (++t.n > 5) throw new UserError('Muitas tentativas. Tente em 15 minutos.'); tries.set(key, t); }
function session(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(sha(token), userId, Date.now() + 7 * DAY);
  return token;
}
function register({ email, birth, password }) {
  email = String(email || '').trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new UserError('E-mail inválido');
  if (!adult(String(birth || ''))) throw new UserError('Cadastro permitido apenas para maiores de 18 anos');
  if (String(password || '').length < 8) throw new UserError('A senha precisa ter 8 caracteres ou mais');
  try {
    const r = db.prepare('INSERT INTO users(email,birth,pw,created) VALUES(?,?,?,?)').run(email, birth, hash(password), new Date().toISOString());
    return session(Number(r.lastInsertRowid));
  } catch (e) { throw new UserError('E-mail já cadastrado'); }
}
function login({ email, password }, ip) {
  email = String(email || '').trim().toLowerCase(); limit(ip + email);
  const u = db.prepare('SELECT id,pw,kyc FROM users WHERE email=?').get(email);
  if (!u || !check(String(password || ''), u.pw)) throw new UserError('E-mail ou senha incorretos');
  if (u.kyc === 'blocked') throw new UserError('Conta bloqueada');
  return session(u.id);
}
function user(req) {
  const t = (/sid=([a-f0-9]{64})/.exec(req.headers.cookie || '') || [])[1]; if (!t) return null;
  return db.prepare('SELECT u.id,u.email,u.kyc,u.balance FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>?').get(sha(t), Date.now()) || null;
}
const logout = req => { const t = (/sid=([a-f0-9]{64})/.exec(req.headers.cookie || '') || [])[1]; if (t) db.prepare('DELETE FROM sessions WHERE token=?').run(sha(t)); };
module.exports = { register, login, user, logout };
