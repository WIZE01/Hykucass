const { DatabaseSync } = require('node:sqlite');
const db = new DatabaseSync(process.env.DB_FILE || 'hykucass.db');
db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, birth TEXT NOT NULL,
  pw TEXT NOT NULL, kyc TEXT NOT NULL DEFAULT 'pending', balance INTEGER NOT NULL DEFAULT 0 CHECK(balance>=0), created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, type TEXT NOT NULL, amount INTEGER NOT NULL,
  balance_after INTEGER NOT NULL, ref TEXT, created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS rounds(id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, game TEXT, choice TEXT, bet INTEGER, payout INTEGER, detail TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS pix_charges(id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, amount INTEGER NOT NULL, status TEXT NOT NULL,
  provider_ref TEXT UNIQUE, code TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS withdrawals(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, amount INTEGER NOT NULL, pix_key TEXT NOT NULL,
  status TEXT NOT NULL, created TEXT);`);
class UserError extends Error {}
function tx(fn) { db.exec('BEGIN IMMEDIATE'); try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; } }
module.exports = { db, tx, UserError };
