// Uso: node simulate.js 1000000  -> RTP real de cada aposta (média do retorno / aposta)
const { impl } = require('./engine');
const { games } = require('./config');
const N = +process.argv[2] || 1000000;
const bets = {
  roulette: [['Cor (vermelho)', { type: 'color', value: 'red' }], ['Número 17', { type: 'number', value: 17 }], ['Verde', { type: 'green' }]],
  bacbo: ['player', 'banker', 'tie'].map(x => [x, x]),
  baccarat: ['player', 'banker', 'tie'].map(x => [x, x]),
  baccarat9: ['player', 'banker', 'tie'].map(x => [x, x])
};
for (const g of Object.keys(bets)) for (const [name, ch] of bets[g]) {
  let total = 0;
  for (let i = 0; i < N; i++) total += impl[g](ch, games[g].payouts).mult;
  console.log(games[g].name.padEnd(20), String(name).padEnd(16), 'RTP', (100 * total / N).toFixed(2) + '%');
}
